export const environment = {
  production: false,
  backendBaseUrl: 'http://localhost:9090/api/v1',
  frontendBaseUrl: 'http://localhost:4200',
};
