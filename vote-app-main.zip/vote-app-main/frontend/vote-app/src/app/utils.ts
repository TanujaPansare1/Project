export const VOTE_BASE_URL = 'http://localhost:8081/api/v1/vote';
export const ELECTION_BASE_URL = 'http://localhost:8081/api/v1/election';
export const PERSON_BASE_URL = 'http://localhost:8081/api/v1/person';
export const ELECTION_RESULT_BASE_URL =
  'http://localhost:8081/api/v1/election-result';
