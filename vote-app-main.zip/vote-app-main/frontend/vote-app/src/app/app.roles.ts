export class AppRoles {
  static Read = 'read';
  static Update = 'update';
  static Admin = 'admin';
}
