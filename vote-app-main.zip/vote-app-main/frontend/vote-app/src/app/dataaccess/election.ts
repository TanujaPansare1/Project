export class Election {
  public id!: number;
  public title = '';
  public description = '';
  public progress = 0;
}
