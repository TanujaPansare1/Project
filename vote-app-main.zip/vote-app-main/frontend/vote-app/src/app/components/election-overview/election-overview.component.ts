import { Component } from '@angular/core';

@Component({
  selector: 'app-election-overview',
  templateUrl: './election-overview.component.html',
  styleUrls: ['./election-overview.component.scss'],
})
export class ElectionOverviewComponent {}
