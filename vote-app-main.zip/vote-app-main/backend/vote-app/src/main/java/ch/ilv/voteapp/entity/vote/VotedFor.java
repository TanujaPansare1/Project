package ch.ilv.voteapp.entity.vote;

public enum VotedFor {
    A, B
}
