package ch.ilv.voteapp.entity.electionresult;

public enum Result {
    A, B
}
