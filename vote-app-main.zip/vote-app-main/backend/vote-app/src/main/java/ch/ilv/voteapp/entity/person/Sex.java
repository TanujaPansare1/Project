package ch.ilv.voteapp.entity.person;

public enum Sex {
    MALE, FEMALE
}
