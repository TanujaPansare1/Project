package ch.ilv.voteapp.security;

public class Roles {
    public static final String Admin = "admin";
    public static final String Read = "read";
    public static final String Update = "update";
}
