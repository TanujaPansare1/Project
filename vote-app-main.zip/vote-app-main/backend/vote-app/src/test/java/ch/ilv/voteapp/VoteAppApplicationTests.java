package ch.ilv.voteapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoteAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
